export class University {
  constructor(name) {
    this.name = name;
    this.image = '';
  }

  setImage(imageUrl) {
    this.image = imageUrl;
  }
}
